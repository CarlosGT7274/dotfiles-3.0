#!/bin/sh
sed -i \
         -e 's/#1E1D2D/rgb(0%,0%,0%)/g' \
         -e 's/#e0def4/rgb(100%,100%,100%)/g' \
    -e 's/#1E1D2D/rgb(50%,0%,0%)/g' \
     -e 's/#F38BA8/rgb(0%,50%,0%)/g' \
     -e 's/#1E1D2D/rgb(50%,0%,50%)/g' \
     -e 's/#e0def4/rgb(0%,0%,50%)/g' \
	"$@"
